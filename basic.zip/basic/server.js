const express = require("express");
const app = express();
const path = require("path");
const request = require("request");
const bodyParser = require('body-parser'); 



const PORT = process.env.PORT || 3001;

// Middleware
app.use(express.static(__dirname + "/public/assets"));
app.use("/", express.static(path.join(__dirname + "/node_modules")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false })); // Parse request body 


app.route("/").get((req, res) => {
  res.sendFile(path.join(__dirname, "/index.html"));
});

//05e978dfa15c4413b3415464a574255d.vfs.cloud9.us-east-1.amazonaws.com/api/languages
// https:
// app.route.get("
// https://05e978dfa15c4413b3415464a574255d.vfs.cloud9.us-east-1.amazonaws.com/api/languages
// ")((req, res) => {
//     console.log('req: ', req);
//     console.log('res: ', res);

// });

// app.route.get("/text/languages", (req,res) => {
//     console.log('req:: ', req);
//     console.log('res:: ', res);

// });

app.route("/test/languages").get((req, res) => {
  var options = {
    method: "GET",
    url:
      "https://05e978dfa15c4413b3415464a574255d.vfs.cloud9.us-east-1.amazonaws.com/api/languages",
    headers: {
      "Postman-Token": "03953934-ba42-4c40-842a-50fe280d2171",
      "cache-control": "no-cache",
      "Content-Type": "application/json"
    },
    form: { undefined: undefined }
  };

  request(options, function(error, response, body) {
    if (error) throw new Error(error);
    console.log(body);
  });
});

// app.get("/api/languages", (req, res) => {
//   //   console.log("req:: ", req);
// });

app.route("/api/languages")
  .get((req, res) => {
    console.log("----------");
    // console.log(req.headers)
   res.json({ "language": req.headers.language, "proficiency": req.headers.proficiency });
  })
  .post((req, res) => {
    console.log("----------");
    console.log("req:: ", req.body);
    // res.json({ code: "success" });
   return res.json(req.body);
  });

// app.post("/api/languages", (req, res) => {
//   console.log("----------");
//   console.log("req:: ", req);
//   res.json({ code: "success" });
// });

app.listen(PORT, err => {
  err ? console.log(err) : console.log(`running:: http:localhost:${PORT}`);
});
