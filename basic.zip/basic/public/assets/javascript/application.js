$(() => {
  console.log("READY!");

  // var default_lang = "English";

  var selected_lang = "English";
  var selected_prof = "Beginner";

  var recorder = {
    initialState: () => {
      recorder.displayRecorder(false);
      $("#level_container").hide();
    },
    displayRecorder: bool => {
      bool ? $("div.recorder").show() : $("div.recorder").hide();
    },
    startApp: () => {
      console.log("START BUTTON CLICKED");

      // Hide Start Button Container
      $("#start_btn_container").hide();

      // Get Proficiency/Language
      $("#level_container").show();
    },
    updateLang: lang => {
      selected_lang = lang;
      console.log("LANG:: ", selected_lang);
    },

    updateProf: prof => {
      selected_prof = prof;
      console.log("PROF:: ", prof);

      recorder.sendLevels({language: selected_lang, proficiency: selected_prof});
    },


    sendLevels: info => {

        // info = JSON.stringify(info)
        // $.post("api/languages", data => {
        //   // $(".result").html(data);
        //     data = info;
        //   return JSON.stringify(data)
        // });

        console.log(JSON.stringify(info));

      $.ajax({
        url: "/api/languages",
        type: "POST",
        // contentType: "json",
        success: msg => {
            console.log(msg);
        },
        data: info
        // dataType: "json"
      })
        .done(function() {
          alert("SUCCESS");
          $.ajax({
            url: "/api/languages",
            type: 'GET',
            // contentType: "json",
            headers: info,
            success: msg => {
                console.log(msg);
            },
            data: ""
            // dataType: "json"
          })
        })


        // .fail(function() {
        //   alert("error");
        // });
    }
  };

  $(".start_btn").click(() => recorder.startApp());
  recorder.initialState();

  // Event Listeners
  $("#language_dropdown").on("click", e =>
    recorder.updateLang(e.target.innerHTML)
  );
  $("#proficiency_dropdown").on("click", e =>
    recorder.updateProf(e.target.innerHTML)
  );
});
